package employee.example.employeeRepository;

import employee.example.models.Employee;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends MongoRepository<Employee,Integer> {

    void deleteByEmpId(int empId);


    Employee findByEmpId(int empId);
}
