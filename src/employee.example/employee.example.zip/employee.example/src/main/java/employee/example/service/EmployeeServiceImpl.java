package employee.example.service;

import employee.example.employeeRepository.EmployeeRepository;
import employee.example.models.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;


    @Override
    public void addEmployee(Employee employee) {
         employeeRepository.save(employee);
    }

    @Override
    public List<Employee> getEmployee() {
         List<Employee>list2 = new ArrayList<>();

         list2.addAll(this.employeeRepository.findAll());
       return  list2;

    }

    @Override
    public String deleteEmployee(int empId) {
        Employee e =employeeRepository.findByEmpId(empId);

        if(e!=null) {
            employeeRepository.deleteByEmpId(empId);
        }

        else{
            return "data not found";
        }

        return "delete employeee";
    }

    @Override
    public List<String> updateEmployee(int empId,Employee employee) {
       Employee emp =employeeRepository.findByEmpId(empId);
         List<String> x = new ArrayList<>();
         if(employee.getEmpName()!=null) {emp.setEmpName(employee.getEmpName()); x.add("name updated");} else{emp.setEmpName(emp.getEmpName());}
         if(employee.getEmpPost()!=null){emp.setEmpPost(employee.getEmpPost());x.add("post updated");} else {emp.setEmpPost(emp.getEmpPost());}
         if(employee.getEmpEmail()!=null){emp.setEmpEmail(employee.getEmpEmail());x.add("email updated");} else {emp.setEmpEmail(emp.getEmpEmail());}
         if(employee.getEmpJoiningDate()!=null) {emp.setEmpJoiningDate(employee.getEmpJoiningDate());x.add("joining date updated");} else{emp.setEmpJoiningDate(emp.getEmpJoiningDate());}
         if(employee.getMobileNumber()!=null) {emp.setMobileNumber(employee.getMobileNumber());x.add("mobile number updated");} else{emp.setMobileNumber(emp.getMobileNumber());}
         employeeRepository.deleteByEmpId(empId);
         employeeRepository.save(emp);

       return  x;

    }

    @Override
    public Employee getEmployeeById(int empId) {


     Employee emp=employeeRepository.findByEmpId(empId);

         return emp;

    }

    @Override
    public String getStatus(int empId,String status) {

        Employee emp = employeeRepository.findByEmpId(empId);


            long millis = System.currentTimeMillis();
            java.sql.Date date = new java.sql.Date(millis);
           String checkIn = String.valueOf(date);
            emp.setStatus(checkIn);
        
        employeeRepository.save(emp);
        return checkIn;
    }


}
