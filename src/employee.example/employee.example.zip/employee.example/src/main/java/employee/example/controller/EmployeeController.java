package employee.example.controller;

import employee.example.models.Employee;
import employee.example.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {



    @Autowired
    private EmployeeService employeeService;



    @RequestMapping(value = "/addEmp", method =RequestMethod.POST)
    public ResponseEntity<String> addEmployee(@RequestBody Employee employee) {
         this.employeeService.addEmployee(employee);
       return ResponseEntity.ok("employee added");
    }

    //
    @GetMapping("/getEmp")
    public ResponseEntity<List<Employee>> getEmployee() {

         return ResponseEntity.ok(this.employeeService.getEmployee());
    }

    @DeleteMapping("/deleteEmp/{empId}")
    public ResponseEntity<String>  deleteEmployee(@PathVariable int empId) {


       return ResponseEntity.ok(this.employeeService.deleteEmployee(empId));
    }

    @PutMapping("/updateEmp/{empId}")
    public ResponseEntity<List<String>> updateEmployee(@PathVariable("empId") int empId,@RequestBody Employee employee){

        return ResponseEntity.ok(this.employeeService.updateEmployee(empId,employee));
    }

    @GetMapping("/getEmployeeById/{empId}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable("empId") int empId){

     return ResponseEntity.ok(this.employeeService.getEmployeeById(empId));
    }

   @GetMapping("/status/{empId}")
    public String getStatus(@PathVariable("empId") int empId, @RequestBody String status)
   {
       return this.employeeService.getStatus(empId,status);
   }




}
