package employee.example.service;

import employee.example.models.Employee;

import java.util.List;
import java.util.Optional;

public interface EmployeeService {
    public void addEmployee(Employee employee);

    public List<Employee> getEmployee();

    public String deleteEmployee(int empId);

    public List<String> updateEmployee(int empId,Employee employee);

    public Employee getEmployeeById(int empId);

  public String getStatus(int empId,String status);
}
